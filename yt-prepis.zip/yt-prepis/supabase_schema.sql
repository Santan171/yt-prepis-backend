-- Spusti v Supabase SQL Editor

create table public.transcripts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  title text not null,
  content text not null,
  source text,
  language text,
  created_at timestamptz default now()
);

-- RLS
alter table public.transcripts enable row level security;

create policy "Users see own transcripts"
  on public.transcripts for select
  using (auth.uid() = user_id);

create policy "Users insert own transcripts"
  on public.transcripts for insert
  with check (auth.uid() = user_id);

create policy "Users delete own transcripts"
  on public.transcripts for delete
  using (auth.uid() = user_id);
