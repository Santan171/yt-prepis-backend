# YT Prepis

Webová aplikácia na prepis YouTube videí a zvukových súborov.

---

## Postup nasadenia

### 1. Supabase

1. Vytvor nový projekt na [supabase.com](https://supabase.com)
2. Choď do **SQL Editor** a spusti obsah súboru `supabase_schema.sql`
3. V **Project Settings → API** si poznač:
   - `Project URL`
   - `anon public` kľúč
   - `service_role` kľúč (tajný!)

---

### 2. Backend → Railway

1. Vytvor nový projekt na [railway.app](https://railway.app)
2. Prepoj GitHub repo alebo nahraj priečinok `backend/`
3. Nastav **Environment Variables**:
   ```
   SUPABASE_URL=https://xxxxx.supabase.co
   SUPABASE_SERVICE_KEY=eyJhbGci...service_role_key...
   ```
4. Railway automaticky spustí `uvicorn main:app` podľa `railway.toml`
5. Po deployi si poznač URL backendu (napr. `https://yt-prepis-backend.railway.app`)

---

### 3. Frontend → Vercel

1. Vytvor nový projekt na [vercel.com](https://vercel.com)
2. Prepoj GitHub repo, nastav **Root Directory** na `frontend/`
3. Nastav **Environment Variables**:
   ```
   NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGci...anon_key...
   NEXT_PUBLIC_API_URL=https://yt-prepis-backend.railway.app
   ```
4. Deploy — Vercel automaticky zbuilduje Next.js

---

## Lokálne spustenie

### Backend
```bash
cd backend
pip install -r requirements.txt
export SUPABASE_URL=...
export SUPABASE_SERVICE_KEY=...
uvicorn main:app --reload
```

### Frontend
```bash
cd frontend
npm install
cp .env.local.example .env.local
# vyplň .env.local
npm run dev
```
